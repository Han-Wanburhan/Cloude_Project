<?php
session_start();
include('server.php');

$errors = array();

if (isset($_POST['like'])) {

    if (count($errors) == 0) {
        $sql = mysqli_query($conn, "SELECT * FROM `like` WHERE id_user = {$_SESSION['user_id']} and id_post = {$_GET['post_id']}");
        if (mysqli_num_rows($sql) == 1) {
            $sql = "DELETE FROM `like` WHERE id_user='{$_SESSION['user_id']}' and id_post = {$_GET['post_id']}";
            mysqli_query($conn, $sql);
        } else {
            $sql = "INSERT INTO `like`(id_user,id_post)VALUES(" . $_SESSION['user_id'] . ",{$_GET['post_id']})";
            mysqli_query($conn, $sql);
        }

        if (isset($_GET['parameterID'])) {
            echo "<script>history.back()</script>";
        } else {
            echo "<script>history.back()</script>";
        }
    }
}
