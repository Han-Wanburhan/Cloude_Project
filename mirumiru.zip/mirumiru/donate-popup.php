<?php include('server.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Document</title>
	<link rel="stylesheet" href="style.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

	<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
	<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
</head>

<body>
	<div class="middle" data-aos="zoom-out">
		<div class="donatepopup">
			<div class="top">
				<div class="donate text-purple"><b>Donate</b></div>
				<div class="close" onclick="window.location.href=window.location.href.split('&')[0];">
					<i class="fas fa-xmark text-purple btn"></i>
				</div>
			</div>
			<div class="bottom">
				<?php
				include('server.php');
				$sql = mysqli_query($conn, "SELECT * FROM user WHERE id = " . $_GET["donate_id"]);
				while ($row = mysqli_fetch_array($sql)) {
				?>
					<div class="details">
						<div class="username text-purple">
							<b>Donate to account :</b> <?php echo $row['name']; ?>
						</div>
					</div>
					<div class="padding-img">
						<div class="qrcode" style="background-image: url('<?php

																			if ($row['img_donate'] == "") {
																				echo "./images/donate/unknown.png";
																			} else {
																				echo $row['img_donate'];
																			}
																			?>');"></div>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/js/all.min.js" integrity="sha512-6PM0qYu5KExuNcKt5bURAoT6KCThUmHRewN3zUFNaoI6Di7XJPTMoT6K0nsagZKk2OB4L7E3q1uQKHNHd4stIQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>



	<script>
		AOS.init();
	</script>
</body>

</html>