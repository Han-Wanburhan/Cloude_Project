<?php include('server.php'); ?>
<?php
session_start();
if (!isset($_SESSION['username'])) {
	$_SESSION['msg'] = "You must log in first";
	header('location: login.php');
}


$sql = "SELECT post.*, USER.*, COUNT(LIKE.id_post) AS like_amount FROM post LEFT JOIN `like` ON post.id = LIKE.id_post LEFT JOIN USER ON post.id_user = USER.id  WHERE post.id=" . $_GET['id'] . " GROUP BY post.id ORDER BY time_stamp DESC";
$result = $conn->query($sql);

?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Post</title>

	<link rel="stylesheet" href="style.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
	<?php require_once("header.php"); ?>
	<?php

	while ($row = $result->fetch_assoc()) {
	?>
		<div class="postviewer">
			<div class="left">
				<div class="close" onclick="history.back()">
					<i class="fas fa-xmark btn"></i>
				</div>
				<div class="behind-box">
					<div class="image_post" style="background-image: url('<?php echo $row['image']; ?>');"></div>
				</div>
			</div>
			<div class="right">
				<div class="top">
					<div class="box">
						<div class="topleft">
							<div class="left">
								<div class="profile-user" style="background-image: url('<?php echo $row['img_profile']; ?>');"></div>
							</div>
							<div class="right">
								<div class="username text-purple cursor-pointer" onclick="window.location.href='profile.php?user=<?php echo $row['id']; ?>'">
									<b><?php echo $row['name']; ?></b>
								</div>
								<div class="timepost"><?php echo date("F j, Y, g:i a", strtotime($row['time_stamp'])); ?></div>
							</div>
						</div>
						<div class="topright">
							<div class="showlike text-purple cursor-pointer" onclick="window.location.href=window.location.href+'&like_post=<?php echo $_GET['id']; ?>'"><?php echo $row['like_amount']; ?></div>
							<form action="like_db.php?return=viewpost&parameterID=<?php echo $_GET['id']; ?>&post_id=<?php echo $_GET['id']; ?>" method="post">
								<div class="btn-like">
									<button type="submit" name="like">
										<i class="fa-solid fa-heart"></i>
									</button>
								</div>
							</form>
							<div class="btn-donate text-purple cursor-pointer" onclick="window.location.href=window.location.href+'&donate_id=<?php echo $row['id']; ?>'">
								<i class="fa-solid fa-circle-dollar-to-slot"></i>
							</div>
						</div>
					</div>
					<div class="bottom">
						<div class="caption">
							<?php echo $row['caption']; ?>
							<div class="edit hidden-recently"><i class="fas fa-pen"></i></div>
						</div>
					</div>
					<hr />
					<div class="comment-list" id="comment-list">
						<?php
						include('server.php');
						$sql = mysqli_query($conn, "SELECT * FROM comment 
									INNER JOIN user on comment.id_user = user.id
									where id_post = " . $_GET['id'] ." ORDER BY time_stamp ASC ");
						while ($row = mysqli_fetch_array($sql)) {
						?>
							<div class="bottom comment-zone">
								<div class="left">
									<div class="profile-user" style="background-image: url('<?php echo $row['img_profile']; ?>');"></div>
								</div>
								<div class="right">
									<div class="username text-purple cursor-pointer" onclick="window.location.href='profile.php?user=<?php echo $row['id']; ?>'">
										<?php echo $row['name']; ?>
									</div>
									<div class="comment"><?php echo $row['text_comment']; ?></div>
								</div>
							</div>
						<?php } ?>
					</div>
					<hr />
					<form action="viewpost_db.php?post=<?php echo $_GET['id']; ?>" method="post">
						<div class="group">
							<div class="comment-textbox">
								<input type="text" placeholder="type comment here ..." name="comment" />
							</div>
							<div class="btn send"><button type="submit" name="create_comment">Send</button></div>
						</div>
					</form>
				</div>
			</div>
		</div>
	<?php } ?>
	<script>
		var element = document.getElementById("comment-list");
		element.scrollTop = element.scrollHeight;
	</script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/js/all.min.js" integrity="sha512-6PM0qYu5KExuNcKt5bURAoT6KCThUmHRewN3zUFNaoI6Di7XJPTMoT6K0nsagZKk2OB4L7E3q1uQKHNHd4stIQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</body>

</html>