<?php
session_start();
if (!isset($_SESSION["user_id"])) {
	header("location: index.php");
}
include('server.php');
if (isset($_POST["submit"])) {
	$name = mysqli_real_escape_string($conn, $_POST["name"]);
	$about_me = mysqli_real_escape_string($conn, $_POST["about_me"]);

	$img_profile_name = $_FILES["img_profile"]["name"];
	$img_profile_tmp_name = $_FILES["img_profile"]["tmp_name"];
	$img_profile_size = $_FILES["img_profile"]["size"];
	$img_profile_new_name = rand() . $img_profile_name;

	$img_profile_type = pathinfo(basename($_FILES["img_profile"]["name"]), PATHINFO_EXTENSION);

	$img_donate_name = $_FILES["img_donate"]["name"];
	$img_donate_tmp_name = $_FILES["img_donate"]["tmp_name"];
	$img_donate_size = $_FILES["img_donate"]["size"];
	$img_donate_new_name = rand() . $img_donate_name;

	$img_donate_type = pathinfo(basename($_FILES["img_donate"]["name"]), PATHINFO_EXTENSION);

	if ($img_profile_size === $img_donate_size > 10485760) {
		echo "<script>alert('Photo is very big. Maxmimum photo uploading size is 10MB. '); </script>";
	} else {
		$sql = "UPDATE USER SET name='$name', about_me='$about_me', img_profile='./images/profile/{$_SESSION['user_id']}.$img_profile_type', img_donate='./images/donate/{$_SESSION['user_id']}.$img_donate_type' WHERE id='{$_SESSION["user_id"]}'";
		$result = mysqli_query($conn, $sql);
		if ($result) {

			move_uploaded_file($img_profile_tmp_name, "images/profile/" . $_SESSION['user_id'] . "." . $img_profile_type);
			move_uploaded_file($img_donate_tmp_name, "images/donate/" . $_SESSION['user_id'] . "." . $img_donate_type);
		} else {
			echo $conn->error;
		}
	}
	header("location: profile.php?user={$_SESSION['user_id']}");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Edit Profile</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

	<link rel="stylesheet" href="style.css" />
</head>

<body bgcolor="#14213D">
	<?php require_once("header.php"); ?>

	<div class="edit-profile">
		<div class="top">
			<div class="box box-1">
				<div class="title text-purple">Edit Profile</div>
				<form action="./edit-profile.php" method="post" enctype="multipart/form-data">
					<?php
					$sql = "SELECT * FROM user WHERE id='{$_SESSION["user_id"]}'";
					$result = mysqli_query($conn, $sql);
					if (mysqli_num_rows($result) > 0) {
						while ($row = mysqli_fetch_assoc($result)) {
					?>
							<div class="close">
								<i class="fas fa-xmark text-purple btn" onclick="window.location.href='profile.php?user=<?php echo $_SESSION['user_id']; ?>'"></i>
							</div>
			</div>
		</div>

		<div class="bottom">

			<div class="box box-3">
				<label class="uploadZone text-purple">
					<div id="txtUploadPreview">Upload Image<br>[ Click Here ]</div>
					<input type="file" accept="image/*" id="img_profile" name="img_profile" onchange="loadFileProfile(event)" style="display: none" />
					<div id="image-profile-output" style="background-image: url('<?php echo $row["img_profile"]; ?>');"></div>
				</label>
			</div>
			<div class="box box-2">
				<div class="group">
					<div class="txt_edit_name text-purple txt">
						Name
					</div>
				</div>

				<div class="txt_input_name">
					<input type="text" placeholder="name" id="name" name="name" value="<?php echo $row['name']; ?>" />
				</div>
			</div>
		</div>

		<div class="box box-4">
			<div class="group">
				<div class="txt_edit_caption text-purple txt">
					Description
				</div>
			</div>
			<div class="box_input_caption">
				<!-- <textarea placeholder="Caption here"></textarea> -->
				<textarea input type="text" placeholder="Caption here" name="about_me"><?php echo $row['about_me']; ?></textarea>
			</div>
		</div>


		<div class="box box-5">
			<div class="group">
				<div class="txt_edit_donation text-purple txt">
					Donation
				</div>
			</div>
			<label class="uploadZone-Donate text-purple">
				<div id="txtUploadPreview-Donate">Upload Image<br>[ Click Here ]</div>
				<input type="file" accept="image/*" id="img_donate" name="img_donate" onchange="loadFileDonate(event)" style="display: none">
				<div id="image-donate-output" style="background-image: url('<?php

																			if ($row['img_donate'] == "") {
																				echo "./images/donate/unknown.png";
																			} else {
																				echo $row['img_donate'];
																			}
																			?>');">
				</div>
			</label>
		</div>
<?php
						}
					}
?>
<div class="bottom-center">
	<!-- <button type="submit" class="btn">Update Profile</button> -->
	<input type="submit" name="submit" class="btn create_acc" value="Edit Profile">
</div>
	</div>
	</div>
	</div>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/js/all.min.js" integrity="sha512-6PM0qYu5KExuNcKt5bURAoT6KCThUmHRewN3zUFNaoI6Di7XJPTMoT6K0nsagZKk2OB4L7E3q1uQKHNHd4stIQ==" crossorigin="anonymous" referrerpolicy="no-referrer">
	</script>
	<script>
		var loadFileProfile = function(event) {

			var output = document.getElementById('image-profile-output');
			output.style.backgroundImage = "url('" + URL.createObjectURL(event.target.files[0]) + "')";
			output.onload = function() {
				URL.revokeObjectURL(output.src) // free memory
			}
			document.getElementById('txtUploadPreview').innerHTML = "";
			document.getElementById('txtUploadPreview').style.background = "none";
		};

		var loadFileDonate = function(event) {

			var output = document.getElementById('image-donate-output');
			output.style.backgroundImage = "url('" + URL.createObjectURL(event.target.files[0]) + "')";
			output.onload = function() {
				URL.revokeObjectURL(output.src) // free memory
			}
			document.getElementById('txtUploadPreview-Donate').innerHTML = "";
			document.getElementById('txtUploadPreview-Donate').style.background = "none";
		};
	</script>
	</form>
</body>

</html>