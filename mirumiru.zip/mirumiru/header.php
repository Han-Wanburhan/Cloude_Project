<?php

$alphabet_check = "";

if (strpos($_SERVER['REQUEST_URI'], '?') !== false) {
	$alphabet_check = '&';
} else {
	$alphabet_check = '?';
}

?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="stylesheet" href="style.css" />

<div class="header">
	<div class="left cursor-pointer" onclick="window.location.href='index.php'">
		<div class="logo"></div>
		<div class="Title">Miru Miru</div>
	</div>
	<div class="right">
		<div class="btnIcon uploadimage" onclick="window.location.href=window.location.href+'<?php echo $alphabet_check; ?>post=1'">
			<i class="fa-solid fa-image"></i>
		</div>
		<div class="btnIcon homepage" onclick="window.location.href='index.php'">
			<i class="fa-solid fa-house-chimney"></i>
		</div>
		<div class="btnIcon goprofile" onclick="window.location.href='profile.php?user=<?php echo $_SESSION['user_id']; ?>'">
			<i class="fa-solid fa-user"></i>
		</div>
		<div class="btnIcon logout" onclick="window.location.href='logout.php?logout=1'">
			<i class="fa-solid fa-right-from-bracket"></i>
		</div>
	</div>
</div>



<?php
if (isset($_GET['donate_id'])) {
	require_once("donate-popup.php");
}
?>

<?php
if (isset($_GET['post'])) {
	require_once("post.php");
}
?>

<?php
if (isset($_GET['like_post'])) {
	require_once("like-popup.php");
}
?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/js/all.min.js" integrity="sha512-6PM0qYu5KExuNcKt5bURAoT6KCThUmHRewN3zUFNaoI6Di7XJPTMoT6K0nsagZKk2OB4L7E3q1uQKHNHd4stIQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>