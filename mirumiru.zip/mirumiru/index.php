<?php include('server.php'); ?>
<?php
session_start();
if (!isset($_SESSION['username'])) {
	$_SESSION['msg'] = "You must log in first";
	header('location: login.php');
}

$sql = "SELECT post.id as postID, post.*, USER.*, COUNT(LIKE.id_post) AS like_amount FROM post LEFT JOIN `like` ON post.id = LIKE.id_post LEFT JOIN USER ON post.id_user = USER.id GROUP BY post.id ORDER BY post.time_stamp DESC";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Home Page</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

	<link rel="stylesheet" href="style.css" />
</head>

<body bgcolor="#14213d">

	<?php require_once("header.php"); ?>
	<?php
	while ($row = $result->fetch_assoc()) {


	?>
		<div class="postbox-container">
			<div class="postbox">
				<div class="top">
					<div class="left">
						<div class="profileimg" style="background-image: url('<?php echo $row['img_profile']; ?>');"></div>
						<div class="box">
							<div class="username text-purple cursor-pointer" onclick="window.location.href='profile.php?user=<?php echo $row['id']; ?>'"><?php echo $row['name']; ?></div>
							<div class="posttime"><?php echo date("F j, Y, g:i a", strtotime($row['time_stamp'])); ?></div>
						</div>
					</div>
					<div class="right">
						<div class="showlike text-purple cursor-pointer" onclick="window.location.href='?everopenpost=1&like_post=<?php echo $row['postID']; ?>'"><?php echo $row['like_amount']; ?></div>
						<form action="like_db.php?return=index&post_id=<?php echo $row['postID']; ?>" method="post">
							<div class="btn-like">
								<button type="submit" name="like">
									<i class="fa-solid fa-heart"></i>
								</button>
							</div>
						</form>
					</div>
					<!-- <i class="fa-regular fa-heart"></i> -->
				</div>
				<div class="imgpost" style="background-image: url('<?php echo $row['image']; ?>');" onclick="window.location.href='viewpost.php?id=<?php echo $row['postID']; ?>'"></div>
				<div class="bottom">
					<div class="top">
						<div class="btn-comment cursor-pointer text-purple" onclick="window.location.href='viewpost.php?id=<?php echo $row['postID']; ?>'">
							<i class="fa-regular fa-comment-dots"></i>
						</div>
						<div class="btn-donate cursor-pointer text-purple" onclick="window.location.href='?everopendonate=1&donate_id=<?php echo $row['id']; ?>'">
							<i class="fa-solid fa-circle-dollar-to-slot"></i>
						</div>
					</div>
					<div class="bottom">
						<div class="caption">
							<?php echo $row['caption']; ?>
						</div>
					</div>

				</div>
			</div>
		</div>
	<?php } ?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/js/all.min.js" integrity="sha512-6PM0qYu5KExuNcKt5bURAoT6KCThUmHRewN3zUFNaoI6Di7XJPTMoT6K0nsagZKk2OB4L7E3q1uQKHNHd4stIQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</body>

</html>